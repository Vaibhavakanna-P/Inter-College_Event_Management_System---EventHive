from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from events.views import google_login_success


urlpatterns = [

    path('admin/', admin.site.urls),

    path('accounts/', include('allauth.urls')),

    path('', include('events.urls')),

    path('google-login-success/', google_login_success),

]

urlpatterns += static(settings.STATIC_URL, document_root=settings.BASE_DIR / "events/static")

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

