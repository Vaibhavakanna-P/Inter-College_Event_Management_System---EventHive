def get_bot_response(message: str) -> dict:
    """
    Simple rule-based chatbot responses.

    Returns a dict in the shape:
    { "response": string, "action": string, "url"?: string }
    """
    if message is None:
        message = ""

    message = message.lower()

    # NOTE: Ordering matters because many intents share the word "event".
    # More specific intents (register/add/feedback) must come before "view events".

    # Greeting
    if any(word in message for word in ["hi", "hello", "hey"]):
        return {
            "response": "Hi! I'm your TN Events Assistant. How can I help you?",
            "action": "none",
            "suggestions": ["📅 Show Events", "📝 Register", "➕ Add Event", "⭐ Feedback", "❓ Help"],
        }

    # Register event
    if any(word in message for word in ["register", "join", "participate", "sign up", "signup"]):
        return {
            "response": (
                "To register:\n"
                "1. Open the Events page\n"
                "2. Select an event\n"
                "3. Click Register\n\n"
                "Want me to open the Events page now?"
            ),
            "action": "ask_redirect",
            "url": "/events",
            "label": "Open Events",
            "suggestions": ["📅 Show Events", "⭐ Feedback", "❓ Help"],
        }

    # Profile
    if any(word in message for word in ["profile", "my profile", "account", "my account"]):
        return {
            "response": "Sure — want me to open your Profile page?",
            "action": "ask_redirect",
            "url": "/profile",
            "label": "Open Profile",
            "suggestions": ["📅 Show Events", "📝 Register", "⭐ Feedback", "❓ Help"],
        }

    # Add event (college side)
    if any(word in message for word in ["add event", "create event", "post event", "add a new event"]):
        return {
            "response": "You can add events from the dashboard. Want me to open it?",
            "action": "ask_redirect",
            "url": "/dashboard",
            "label": "Open Dashboard",
            "suggestions": ["📅 Show Events", "⭐ Feedback", "❓ Help"],
        }

    # Feedback
    if any(word in message for word in ["feedback", "rating", "review", "rate event"]):
        return {
            "response": "Sure. Want to open the page where you can submit feedback?",
            "action": "ask_redirect",
            "url": "/my-events",
            "label": "Open My Events",
            "suggestions": ["📅 Show Events", "📝 Register", "❓ Help"],
        }

    # Deadline
    if any(word in message for word in ["deadline", "last date", "due date", "last day"]):
        return {
            "response": "Each event has its deadline listed on the event details. Want to open Events?",
            "action": "ask_redirect",
            "url": "/events",
            "label": "Open Events",
            "suggestions": ["📅 Show Events", "⭐ Feedback", "❓ Help"],
        }

    # Help / navigation
    if any(word in message for word in ["help", "how to use", "guide"]):
        return {
            "response": (
                "You can:\n"
                "- View events\n"
                "- Register for events\n"
                "- Add events (for colleges)\n"
                "- Give feedback\n\n"
                "What would you like to do?"
            ),
            "action": "none",
            "suggestions": ["📅 Show Events", "📝 Register", "➕ Add Event", "⭐ Feedback"],
        }

    # View events
    if any(word in message for word in ["show events", "list events", "events", "programs", "competitions", "event"]):
        return {
            "response": (
                "Here are some events you can explore:\n"
                "1. Hackathon\n"
                "2. Workshop\n"
                "3. Coding Contest\n\n"
                "Want me to open the Events page?"
            ),
            "action": "ask_redirect",
            "url": "/events",
            "label": "Open Events",
            "suggestions": ["📝 Register", "⭐ Feedback", "➕ Add Event"],
        }

    # Default fallback
    return {
        "response": "Sorry, I didn't understand. Try asking about events, registration, or feedback.",
        "action": "none",
        "suggestions": ["📅 Show Events", "📝 Register", "⭐ Feedback", "❓ Help"],
    }

