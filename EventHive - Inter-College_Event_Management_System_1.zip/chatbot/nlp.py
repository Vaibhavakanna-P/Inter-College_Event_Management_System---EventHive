import nltk
import random
from nltk.stem import PorterStemmer
from nltk.tokenize import word_tokenize
from nltk.classify import NaiveBayesClassifier

# Download required data
try:
    nltk.data.find('tokenizers/punkt')
except:
    nltk.download('punkt')

stemmer = PorterStemmer()

# Training data
training_data = [
    ("hi", "greeting"),
    ("hello", "greeting"),
    ("hey", "greeting"),

    ("show events", "view_events"),
    ("list events", "view_events"),
    ("what events are available", "view_events"),
    ("any competitions", "view_events"),

    ("register event", "register_event"),
    ("join event", "register_event"),
    ("participate in event", "register_event"),

    ("add event", "add_event"),
    ("create event", "add_event"),

    ("deadline of event", "deadline"),
    ("last date", "deadline"),

    ("give feedback", "feedback"),
    ("rating", "feedback"),
]

# Responses
responses = {
    "greeting": "Hi! How can I help you?",
    "view_events": "Here are events: Hackathon, Workshop, Coding Contest.",
    "register_event": "Go to events page and click register.",
    "add_event": "Go to dashboard to add events.",
    "deadline": "Deadlines are mentioned in event details.",
    "feedback": "Submit feedback after attending event."
}

# Preprocess
def preprocess(sentence):
    words = word_tokenize(sentence.lower())
    return [stemmer.stem(word) for word in words]

# Feature extraction
def extract_features(sentence):
    words = preprocess(sentence)
    return {word: True for word in words}

# Prepare training set
training_set = [(extract_features(text), intent) for (text, intent) in training_data]

# Train model
classifier = NaiveBayesClassifier.train(training_set)

# Get response
def get_nlp_response(message):
    try:
        features = extract_features(message)
        intent = classifier.classify(features)

        return responses.get(intent, "Sorry, I didn’t understand.")

    except Exception as e:
        print("NLP ERROR:", e)
        return "Something went wrong."