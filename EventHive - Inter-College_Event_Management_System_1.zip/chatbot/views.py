import json

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

from .intents import get_bot_response

@csrf_exempt
def chatbot_view(request):
    if request.method != "POST":
        return JsonResponse({"error": "Method not allowed"}, status=405)

    try:
        body = request.body.decode("utf-8") if request.body else "{}"
        data = json.loads(body)
    except json.JSONDecodeError:
        return JsonResponse({"error": "Invalid JSON payload"}, status=400)

    message = (data.get("message") or "").strip()
    if not message:
        return JsonResponse({"error": "Missing 'message' field"}, status=400)

    bot = get_bot_response(message)

    # Always return a consistent shape for the frontend.
    if "action" not in bot:
        bot["action"] = "none"

    return JsonResponse(bot)